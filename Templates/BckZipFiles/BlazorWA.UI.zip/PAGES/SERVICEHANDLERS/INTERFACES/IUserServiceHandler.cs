﻿using BlazorWA.ViewModels.Auth;
using BlazorWA.ViewModels.Models;

namespace $safeprojectname$.Pages.ServiceHandlers.Interfaces
{
    public interface IUserServiceHandler
    {
        Task<AuthenticationResponse> LoginAsync();
        Task<bool> IsTokenExpiredAsync();
        Task<UserVM> GetLoginUserDetailsAsync();
    }
}

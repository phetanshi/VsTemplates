﻿using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using BlazorWA.Api.Services.Interfaces;
using BlazorWA.Api.Services.Definitions;

namespace $safeprojectname$.Api.Services
{
    public class SampleServiceTests
    {

    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    public enum UiMargin
    {
        [Description("none")]
        None,
        [Description("dense")]
        Dense,
        [Description("normal")]
        Normal
    }
}

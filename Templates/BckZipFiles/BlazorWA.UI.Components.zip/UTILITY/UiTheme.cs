﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    public class UiTheme
    {
        public const string Primary = "#2f749a";
        public const string Secondary = "#ffffff";
    }
}

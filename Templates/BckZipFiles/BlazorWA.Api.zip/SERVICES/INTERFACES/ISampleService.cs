﻿using BlazorWA.Domain;
using BlazorWA.ViewModels.Models;

namespace $safeprojectname$.Services.Interfaces
{
    public interface ISampleService
    {
        Task<List<UserVM>> GetUsers();
    }
}

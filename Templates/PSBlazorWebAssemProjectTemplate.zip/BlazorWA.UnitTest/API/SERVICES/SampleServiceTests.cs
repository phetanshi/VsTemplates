﻿using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using $ext_projectname$.Api.Services.Interfaces;
using $ext_projectname$.Api.Services.Definitions;

namespace $safeprojectname$.Api.Services
{
    public class SampleServiceTests
    {

    }
}

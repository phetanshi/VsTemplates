﻿namespace $safeprojectname$.UI.Components.Shared
{
    public class MainLayoutTests
    {
        [Fact]
        public void MainLayout_WhenCalled()
        {
            
        }
    }
}
